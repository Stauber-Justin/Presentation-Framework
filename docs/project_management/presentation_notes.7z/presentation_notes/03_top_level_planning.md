# Folie 5 – Top-Level-Planung: Wasserfallmodell

„Das **Wasserfallmodell** bietet einen **klaren Phasen­rahmen** von **Lasten-** über **Pflichten­heft** bis hin zu **Testing** und **Rollout**.

Es schafft **eindeutige Meilensteine** und **Verantwortlichkeiten** – **ideal für** die **Grobplanung** und die **Dokumentation** nach **DIN/ISO-Standards**.

Allerdings **fehlt** hier die **Flexibilität** für **kurzfristige Änderungen**.“
