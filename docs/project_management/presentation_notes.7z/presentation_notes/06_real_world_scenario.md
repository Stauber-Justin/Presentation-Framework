# Folie 11 – Praxisbeispiel: C++11 → C++17 Migration

„In unserem **Praxisbeispiel** **migrieren** wir eine **C++11-Codebasis auf C++17**.

Wir legen **Epics und User Stories im Scrum-Backlog** an, **planen zwei­wöchige Sprints mit Story-Points** und führen **Daily Stand-ups**, -
**Sprint-Reviews** und **Retrospektiven** durch.

So **behalten** wir jederzeit den **Überblick** und **passen uns flexibel** an.“