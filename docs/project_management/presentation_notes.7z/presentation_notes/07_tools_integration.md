# Folie 13 – Tools, Metriken & Governance

„Für das **Backlog-Management** nutzen wir **Jira**, **Confluence** dient **als zentrale Wissens­datenbank**.

Unsere **CI/CD-Pipeline** (GitLab CI oder Jenkins) **automatisiert Builds und Tests**.

**Wichtige Metriken** sind **Velocity**, **Burndown** und der **Cumulative-Flow-Chart** zur **Steuerung der Kapazität**.“