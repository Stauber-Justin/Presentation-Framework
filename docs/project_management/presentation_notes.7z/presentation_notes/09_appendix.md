# Folie 15 – Anlagen / Appendix

## Huh?