# Folie 3 – Ausgangssituation & Herausforderungen

„Kennen Sie das: **Projekte verzögern** sich, weil **Änderungen spät sichtbar** werden?

**Klassische Phasen­modelle** wie **Wasserfall** verursachen **lange Feedback-Zyklen**, die **Time-to-Market verlängern**.

Gleichzeitig **steigt** die **Komplexität moderner Systeme**, und **starre Prozesse** lassen uns **nicht flexibel** reagieren.“
