# Folie 1 – Deckblatt

„Guten Tag und herzlich willkommen zu meiner Präsentation ‚**Modernes Projektmanagement** – Hybrid Modell: **Wasserfall trifft Agile**‘.

Ich bin [Dein Name] und freue mich, Ihnen heute in knapp 20 Minuten darzulegen, wie wir klassische Vorgehensmodelle durch ein **hybrides** Framework effizient ergänzen können.

Lassen Sie uns direkt einsteigen.
